import { Component, OnInit, ViewChild, ElementRef } from '@angular/core';
import * as jsPDF from 'jspdf';
declare var xepOnline: any;

@Component({
  selector: 'app-htmltopdf',
  templateUrl: './htmltopdf.component.html',
  styleUrls: ['./htmltopdf.component.css']
})
export class HtmltopdfComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  
  @ViewChild('content') content: ElementRef;
  
  public downloadPDF(){
    return xepOnline.Formatter.Format('content', {render:'view'});
  }
}
